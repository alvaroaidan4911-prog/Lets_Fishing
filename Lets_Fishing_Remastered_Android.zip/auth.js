// ============================================================
// LET'S FISHING — AUTH + MAIN MENU + CHARACTER CUSTOMIZER v3
// Landscape layout · Three.js 3D preview · Firebase Auth
// ============================================================
(function(){"use strict";

// ── SDK URLs ──────────────────────────────────────────────
const FB_APP  = "https://www.gstatic.com/firebasejs/9.23.0/firebase-app-compat.js";
const FB_DB   = "https://www.gstatic.com/firebasejs/9.23.0/firebase-database-compat.js";
const FB_AUTH = "https://www.gstatic.com/firebasejs/9.23.0/firebase-auth-compat.js";

// ── Character data ────────────────────────────────────────
const SKIN_TONES = ["#ffd6b3","#f5c5a3","#d4a574","#c68642","#8d5524","#4a2c0a"];
const HAIR_STYLES = [
  {id:"none",  label:"Botak"},
  {id:"short", label:"Pendek"},
  {id:"medium",label:"Sedang"},
  {id:"long",  label:"Panjang"},
  {id:"spiky", label:"Spike"},
  {id:"bun",   label:"Bun"},
];
const FACE_TYPES = [
  {id:"happy", label:"😊 Senang"},
  {id:"cool",  label:"😎 Cool"},
  {id:"sleepy",label:"😴 Ngantuk"},
  {id:"angry", label:"😠 Serius"},
  {id:"wink",  label:"😉 Wink"},
];
const ACCESSORIES = [
  {id:"none",      label:"❌ Tidak Ada"},
  {id:"glasses",   label:"👓 Kacamata"},
  {id:"sunglasses",label:"🕶 Hitam"},
  {id:"hat",       label:"🎩 Topi"},
  {id:"cap",       label:"🧢 Cap"},
  {id:"headband",  label:"🎀 Headband"},
  {id:"crown",     label:"👑 Mahkota"},
];
const SHIRT_PRESETS = ["#2ecc71","#3498db","#e74c3c","#f39c12","#9b59b6","#1abc9c","#e67e22","#ecf0f1","#2c3e50","#e91e63","#ff5722","#795548"];
const PANTS_PRESETS = ["#2c3e50","#1a5276","#784212","#1e8449","#7d3c98","#922b21","#1c2833","#17202a"];
const HAIR_COLORS   = ["#1a1a1a","#3d1c00","#6b3a1f","#8B4513","#c8a96e","#f7e7ce","#e74c3c","#3498db","#2ecc71","#9b59b6","#f39c12","#95a5a6"];

// ── State ─────────────────────────────────────────────────
let authInst = null, curUser = null;
const charState = {
  skinTone:"#ffd6b3", hairStyle:"short", hairColor:"#3d1c00",
  faceType:"happy",   shirtColor:"#2ecc71", pantsColor:"#2c3e50", accessory:"none"
};

// ─────────────────────────────────────────────────────────
// SDK LOADER
// ─────────────────────────────────────────────────────────
function loadScript(src,cb){
  const s=document.createElement("script");s.src=src;s.onload=cb;
  s.onerror=()=>console.error("LF_Auth: failed",src);
  document.head.appendChild(s);
}
function loadSDKs(cb){
  if(window.firebase&&window.firebase.auth){cb();return;}
  if(window.firebase&&window.firebase.database){
    loadScript(FB_AUTH,cb);return;
  }
  if(window.firebase){
    loadScript(FB_DB,()=>loadScript(FB_AUTH,cb));return;
  }
  loadScript(FB_APP,()=>loadScript(FB_DB,()=>loadScript(FB_AUTH,cb)));
}

// ─────────────────────────────────────────────────────────
// SAVE / LOAD
// ─────────────────────────────────────────────────────────
function saveChar(){
  localStorage.setItem("lf_char",JSON.stringify(charState));
  localStorage.setItem("playerShirt",   charState.shirtColor);
  localStorage.setItem("lf_skinTone",   charState.skinTone);
  localStorage.setItem("lf_hairStyle",  charState.hairStyle);
  localStorage.setItem("lf_hairColor",  charState.hairColor);
  localStorage.setItem("lf_faceType",   charState.faceType);
  localStorage.setItem("lf_pantsColor", charState.pantsColor);
  localStorage.setItem("lf_accessory",  charState.accessory);
}
function loadChar(){
  try{const s=JSON.parse(localStorage.getItem("lf_char")||"{}");Object.assign(charState,s);}catch(e){}
  if(localStorage.getItem("playerShirt")) charState.shirtColor=localStorage.getItem("playerShirt");
}

// ─────────────────────────────────────────────────────────
// THREE.JS 3D CHARACTER PREVIEW
// ─────────────────────────────────────────────────────────
let _previewRaf = null;
let _previewRenderer = null;

function buildFaceTexture(){
  const c=document.createElement("canvas");c.width=256;c.height=256;
  const x=c.getContext("2d");
  const ft=charState.faceType, s=256;
  x.fillStyle="#111";
  if(ft==="happy"){
    x.beginPath();x.arc(s*.31,s*.43,s*.047,0,Math.PI*2);x.fill();
    x.beginPath();x.arc(s*.69,s*.43,s*.047,0,Math.PI*2);x.fill();
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.arc(s*.5,s*.62,s*.16,0,Math.PI);x.stroke();
  } else if(ft==="cool"){
    x.beginPath();x.arc(s*.31,s*.43,s*.047,0,Math.PI*2);x.fill();
    x.beginPath();x.arc(s*.69,s*.43,s*.047,0,Math.PI*2);x.fill();
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.moveTo(s*.34,s*.72);x.lineTo(s*.5,s*.69);x.lineTo(s*.66,s*.72);x.stroke();
  } else if(ft==="sleepy"){
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.arc(s*.31,s*.45,s*.047,Math.PI,2*Math.PI);x.stroke();
    x.beginPath();x.arc(s*.69,s*.45,s*.047,Math.PI,2*Math.PI);x.stroke();
    x.beginPath();x.arc(s*.5,s*.65,s*.12,0,Math.PI);x.stroke();
  } else if(ft==="angry"){
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.moveTo(s*.24,s*.37);x.lineTo(s*.4,s*.42);x.stroke();
    x.beginPath();x.moveTo(s*.76,s*.37);x.lineTo(s*.6,s*.42);x.stroke();
    x.fillStyle="#111";
    x.beginPath();x.arc(s*.31,s*.47,s*.043,0,Math.PI*2);x.fill();
    x.beginPath();x.arc(s*.69,s*.47,s*.043,0,Math.PI*2);x.fill();
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.moveTo(s*.37,s*.72);x.lineTo(s*.63,s*.72);x.stroke();
  } else { // wink
    x.beginPath();x.arc(s*.31,s*.43,s*.047,0,Math.PI*2);x.fill();
    x.strokeStyle="#111";x.lineWidth=s*.022;
    x.beginPath();x.arc(s*.69,s*.45,s*.047,Math.PI,2*Math.PI);x.stroke();
    x.beginPath();x.arc(s*.5,s*.62,s*.16,0,Math.PI);x.stroke();
  }
  return new THREE.CanvasTexture(c);
}

function buildHairMesh(THREE){
  const hc = parseInt(charState.hairColor.replace("#",""),16);
  const mat = new THREE.MeshStandardMaterial({color:hc,roughness:.8});
  const grp = new THREE.Group();
  const hs = charState.hairStyle;
  if(hs==="none") return grp;
  if(hs==="short"){
    const m=new THREE.Mesh(new THREE.SphereGeometry(.78,16,10,[0,Math.PI*2,0,Math.PI*.55]),mat);
    m.position.y=.05;grp.add(m);
  } else if(hs==="medium"){
    const m=new THREE.Mesh(new THREE.SphereGeometry(.8,16,10,[0,Math.PI*2,0,Math.PI*.6]),mat);
    m.position.y=.06;grp.add(m);
    // side strips
    [-1,1].forEach(side=>{
      const s=new THREE.Mesh(new THREE.BoxGeometry(.22,.8,.3),mat);
      s.position.set(side*.68,-0.3,0);grp.add(s);
    });
  } else if(hs==="long"){
    const m=new THREE.Mesh(new THREE.SphereGeometry(.8,16,10,[0,Math.PI*2,0,Math.PI*.58]),mat);
    m.position.y=.06;grp.add(m);
    [-1,1].forEach(side=>{
      const s=new THREE.Mesh(new THREE.BoxGeometry(.22,1.6,.3),mat);
      s.position.set(side*.68,-0.7,0);grp.add(s);
    });
    const back=new THREE.Mesh(new THREE.BoxGeometry(.9,1.4,.15),mat);
    back.position.set(0,-.7,-.6);grp.add(back);
  } else if(hs==="spiky"){
    const base=new THREE.Mesh(new THREE.SphereGeometry(.76,16,10,[0,Math.PI*2,0,Math.PI*.5]),mat);
    base.position.y=.04;grp.add(base);
    const spikePos=[[0,.9,0],[-.35,.8,.2],[.35,.8,.2],[-.5,.6,-.1],[.5,.6,-.1]];
    spikePos.forEach(([x,y,z])=>{
      const cone=new THREE.Mesh(new THREE.ConeGeometry(.12,.55,5),mat);
      cone.position.set(x,y,z);
      const d=new THREE.Vector3(x,y-.3,z).normalize();
      cone.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),d);
      grp.add(cone);
    });
  } else if(hs==="bun"){
    const m=new THREE.Mesh(new THREE.SphereGeometry(.78,16,10,[0,Math.PI*2,0,Math.PI*.55]),mat);
    m.position.y=.04;grp.add(m);
    const bun=new THREE.Mesh(new THREE.SphereGeometry(.32,12,10),mat);
    bun.position.set(0,.9,-.3);grp.add(bun);
  }
  return grp;
}

function buildAccessoryMesh(THREE){
  const grp=new THREE.Group();
  const acc=charState.accessory;
  if(acc==="none") return grp;
  if(acc==="glasses"||acc==="sunglasses"){
    const lensMat=new THREE.MeshStandardMaterial({
      color:acc==="sunglasses"?0x111133:0xffffff,
      transparent:true,opacity:acc==="sunglasses"?.8:.3,
      roughness:.1,metalness:.2
    });
    const frameMat=new THREE.MeshStandardMaterial({color:0x222222,roughness:.4});
    [-1,1].forEach(side=>{
      const lens=new THREE.Mesh(new THREE.CylinderGeometry(.22,.22,.04,16),lensMat);
      lens.rotation.x=Math.PI/2;
      lens.position.set(side*.3,.05,.72);grp.add(lens);
      const ring=new THREE.Mesh(new THREE.TorusGeometry(.22,.03,8,16),frameMat);
      ring.rotation.x=Math.PI/2;
      ring.position.set(side*.3,.05,.72);grp.add(ring);
    });
    const bridge=new THREE.Mesh(new THREE.CylinderGeometry(.025,.025,.18,6),frameMat);
    bridge.rotation.z=Math.PI/2;bridge.position.set(0,.05,.72);grp.add(bridge);
  } else if(acc==="hat"){
    const brimMat=new THREE.MeshStandardMaterial({color:0x5d3a1a,roughness:.9});
    const brim=new THREE.Mesh(new THREE.CylinderGeometry(1.1,1.1,.08,20),brimMat);
    brim.position.y=.62;grp.add(brim);
    const top=new THREE.Mesh(new THREE.CylinderGeometry(.65,.7,.9,20),brimMat);
    top.position.y=1.07;grp.add(top);
  } else if(acc==="cap"){
    const capMat=new THREE.MeshStandardMaterial({color:0xe74c3c,roughness:.8});
    const dome=new THREE.Mesh(new THREE.SphereGeometry(.8,16,10,[0,Math.PI*2,0,Math.PI*.55]),capMat);
    dome.position.y=.06;grp.add(dome);
    const visor=new THREE.Mesh(new THREE.CylinderGeometry(.65,.75,.06,16,[0,Math.PI]),capMat);
    visor.rotation.y=Math.PI;visor.position.set(0,.42,.55);grp.add(visor);
  } else if(acc==="headband"){
    const mat=new THREE.MeshStandardMaterial({color:0xe74c3c,roughness:.7});
    const band=new THREE.Mesh(new THREE.TorusGeometry(.8,.08,8,40,[0,Math.PI*1.1]),mat);
    band.rotation.x=-Math.PI*.08;band.position.y=.3;grp.add(band);
  } else if(acc==="crown"){
    const mat=new THREE.MeshStandardMaterial({color:0xf1c40f,roughness:.4,metalness:.6});
    const base=new THREE.Mesh(new THREE.CylinderGeometry(.82,.78,.2,20),mat);
    base.position.y=.72;grp.add(base);
    const pts=[[-1,0],[-.6,1],[-.2,.4],[.2,.4],[.6,1],[1,0]];
    for(let i=0;i<pts.length-1;i++){
      const [ax,ay]=pts[i],[bx,by]=pts[i+1];
      const spike=new THREE.Mesh(new THREE.CylinderGeometry(.04,.1,.5+(ay+by)*.2,5),mat);
      spike.position.set(ax*.75,.9+(ay*.22),0);grp.add(spike);
    }
    // gems
    const gemMat=new THREE.MeshStandardMaterial({color:0xe74c3c,roughness:.1,metalness:.8});
    [-.55,0,.55].forEach(x=>{
      const gem=new THREE.Mesh(new THREE.SphereGeometry(.09,8,8),gemMat);
      gem.position.set(x,1.0,0);grp.add(gem);
    });
  }
  return grp;
}

function init3DPreview(container){
  if(!window.THREE){
    // Three.js not yet loaded; draw placeholder
    container.style.background="linear-gradient(135deg,#0a1628,#1a3a5c)";
    container.innerHTML='<div style="display:flex;height:100%;align-items:center;justify-content:center;flex-direction:column;gap:8px;color:#3a6a9a;font-size:13px;"><div style="font-size:40px">🎣</div>Preview<br><span style="font-size:10px">Memuat Three.js...</span></div>';
    return null;
  }
  const THREE=window.THREE;
  // Cleanup old renderer
  if(_previewRenderer){
    cancelAnimationFrame(_previewRaf);
    try{_previewRenderer.dispose();}catch(e){}
    _previewRenderer=null;
  }
  container.innerHTML="";

  // Use offsetWidth for reliable measurement after layout
  const W=container.offsetWidth||container.clientWidth||300;
  const H=container.offsetHeight||container.clientHeight||420;
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true});
  renderer.setSize(W,H,false);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));
  renderer.shadowMap.enabled=true;
  renderer.domElement.style.cssText="display:block;width:100%;height:100%;";
  container.appendChild(renderer.domElement);
  _previewRenderer=renderer;

  // Handle resize
  const resizeObs=new ResizeObserver(()=>{
    const nW=container.offsetWidth, nH=container.offsetHeight;
    if(nW>0&&nH>0){renderer.setSize(nW,nH,false);camera.aspect=nW/nH;camera.updateProjectionMatrix();}
  });
  resizeObs.observe(container);

  const scene=new THREE.Scene();
  // Gradient background
  scene.background=new THREE.Color(0x071830);

  const camera=new THREE.PerspectiveCamera(45,W/H,.1,100);
  camera.position.set(0,4,9);camera.lookAt(0,3,0);

  // Lights
  scene.add(new THREE.AmbientLight(0xffffff,.6));
  const dir=new THREE.DirectionalLight(0x7ecfff,.8);
  dir.position.set(3,8,4);dir.castShadow=true;scene.add(dir);
  const fill=new THREE.DirectionalLight(0xffd6b3,.3);
  fill.position.set(-3,2,-2);scene.add(fill);
  const rim=new THREE.DirectionalLight(0x3498db,.4);
  rim.position.set(0,6,-5);scene.add(rim);

  // Platform
  const platMat=new THREE.MeshStandardMaterial({color:0x0d2040,roughness:.8,metalness:.2});
  const plat=new THREE.Mesh(new THREE.CylinderGeometry(2,2,.12,32),platMat);
  plat.position.y=-.06;plat.receiveShadow=true;scene.add(plat);
  // Platform glow ring
  const ringMat=new THREE.MeshBasicMaterial({color:0x3498db,transparent:true,opacity:.4});
  const ring=new THREE.Mesh(new THREE.TorusGeometry(2,.04,6,40),ringMat);
  ring.rotation.x=Math.PI/2;ring.position.y=.01;scene.add(ring);

  // Build character group
  const charGroup=new THREE.Group();
  scene.add(charGroup);

  const skinHex=parseInt(charState.skinTone.replace("#",""),16);
  const shirtHex=parseInt(charState.shirtColor.replace("#",""),16);
  const pantsHex=parseInt(charState.pantsColor.replace("#",""),16);

  const skinMat=new THREE.MeshStandardMaterial({color:skinHex,roughness:.7});
  const shirtMat=new THREE.MeshStandardMaterial({color:shirtHex,roughness:.8});
  const pantsMat=new THREE.MeshStandardMaterial({color:pantsHex,roughness:.9});
  const shoeMat=new THREE.MeshStandardMaterial({color:0x1a1a1a,roughness:.9});

  // Torso
  const torso=new THREE.Mesh(new THREE.BoxGeometry(2,2,1),shirtMat);
  torso.position.y=3;torso.castShadow=true;charGroup.add(torso);
  // Collar detail
  const collar=new THREE.Mesh(new THREE.BoxGeometry(1,.2,.12),new THREE.MeshStandardMaterial({color:parseInt(charState.shirtColor.replace("#",""),16),roughness:.6}));
  collar.position.set(0,1.1,.57);torso.add(collar);

  // Head
  const head=new THREE.Mesh(new THREE.SphereGeometry(.75,24,24),skinMat);
  head.scale.y=1.05;head.position.y=1.9;head.castShadow=true;torso.add(head);

  // Face
  const faceTex=buildFaceTexture();
  const faceMesh=new THREE.Mesh(
    new THREE.PlaneGeometry(.9,.9),
    new THREE.MeshBasicMaterial({map:faceTex,transparent:true})
  );
  faceMesh.position.z=.74;head.add(faceMesh);

  // Hair
  const hairGrp=buildHairMesh(THREE);
  head.add(hairGrp);

  // Accessory
  const accGrp=buildAccessoryMesh(THREE);
  head.add(accGrp);

  // Neck
  const neck=new THREE.Mesh(new THREE.CylinderGeometry(.28,.32,.35,12),skinMat);
  neck.position.y=1.02;torso.add(neck);

  // Arms
  const armGeo=new THREE.BoxGeometry(1,2,1);
  const armL=new THREE.Mesh(armGeo,shirtMat);armL.position.set(-1.5,0,0);armL.castShadow=true;torso.add(armL);
  const armR=new THREE.Mesh(armGeo,shirtMat);armR.position.set(1.5,0,0);armR.castShadow=true;torso.add(armR);
  // Hands
  const handGeo=new THREE.SphereGeometry(.34,10,10);
  [armL,armR].forEach(arm=>{
    const h=new THREE.Mesh(handGeo,skinMat);h.position.y=-1.18;arm.add(h);
  });

  // Legs
  const legGeo=new THREE.BoxGeometry(1,2,1);
  const legL=new THREE.Mesh(legGeo,pantsMat);legL.position.set(-.5,-2,0);legL.castShadow=true;torso.add(legL);
  const legR=new THREE.Mesh(legGeo,pantsMat);legR.position.set(.5,-2,0);legR.castShadow=true;torso.add(legR);
  // Shoes
  const shoeGeo=new THREE.BoxGeometry(1.1,.35,1.35);
  [legL,legR].forEach(leg=>{
    const shoe=new THREE.Mesh(shoeGeo,shoeMat);shoe.position.set(0,-1.18,.15);leg.add(shoe);
  });

  // Fishing rod (right hand accent)
  const rodMat=new THREE.MeshStandardMaterial({color:0x8b5a2b,roughness:.8});
  const rod=new THREE.Mesh(new THREE.CylinderGeometry(.03,.06,3),rodMat);
  rod.position.set(.6,-1.2,.3);rod.rotation.z=-.4;rod.rotation.x=-.3;
  armR.add(rod);

  charGroup.scale.set(.8,.8,.8);

  // Auto-rotate
  let rotY=0, time=0;
  let rafId;
  function animate(){
    rafId=requestAnimationFrame(animate);
    time+=.016;
    rotY+=.008;
    charGroup.rotation.y=rotY;
    // subtle idle bob
    charGroup.position.y=Math.sin(time*1.2)*.06;
    // ring pulse
    ring.material.opacity=.3+Math.sin(time*2)*.15;
    renderer.render(scene,camera);
  }
  _previewRaf=rafId;
  animate();

  // Return update function
  return function updatePreview(){
    // Update colors
    torso.material.color.setHex(parseInt(charState.shirtColor.replace("#",""),16));
    armL.material.color.setHex(parseInt(charState.shirtColor.replace("#",""),16));
    armR.material.color.setHex(parseInt(charState.shirtColor.replace("#",""),16));
    const sk=parseInt(charState.skinTone.replace("#",""),16);
    head.material.color.setHex(sk);
    [armL,armR].forEach(arm=>arm.children.forEach(c=>{if(c.material===skinMat)c.material.color.setHex(sk);}));
    skinMat.color.setHex(sk);
    const pt=parseInt(charState.pantsColor.replace("#",""),16);
    legL.material.color.setHex(pt);legR.material.color.setHex(pt);

    // Rebuild hair
    while(head.children.length>0) head.remove(head.children[0]);
    head.add(faceMesh);
    const newFaceTex=buildFaceTexture();
    faceMesh.material.map=newFaceTex;faceMesh.material.needsUpdate=true;
    head.add(buildHairMesh(THREE));
    head.add(buildAccessoryMesh(THREE));
  };
}

// ─────────────────────────────────────────────────────────
// APPLY TO GAME CHARACTER (after game loads)
// ─────────────────────────────────────────────────────────
function applyToGameCharacter(){
  try{
    if(typeof window.setShirt==="function") window.setShirt(charState.shirtColor);
    else if(window.torso) window.torso.material.color.set(charState.shirtColor);
    const sk=parseInt(charState.skinTone.replace("#",""),16);
    if(window.head&&window.head.material) window.head.material.color.setHex(sk);
    if(window.armL&&window.armL.material) window.armL.material.color.setHex(sk);
    if(window.armR&&window.armR.material) window.armR.material.color.setHex(sk);
    const pt=parseInt(charState.pantsColor.replace("#",""),16);
    if(window.legL&&window.legL.material) window.legL.material.color.setHex(pt);
    if(window.legR&&window.legR.material) window.legR.material.color.setHex(pt);
  }catch(e){console.warn("applyChar:",e);}
}

// ─────────────────────────────────────────────────────────
// BUILD CSS + HTML
// ─────────────────────────────────────────────────────────
function buildUI(){
  const root=document.createElement("div");
  root.id="lfAuthRoot";
  root.innerHTML=`
<style>
#lfAuthRoot{
  position:fixed;inset:0;z-index:99999;
  font-family:'Segoe UI',Arial,sans-serif;
  background:linear-gradient(160deg,#010c1e 0%,#041630 50%,#061d3a 100%);
  overflow:hidden;
}
/* Ocean */
.lf-ocean{position:absolute;bottom:0;left:0;width:100%;height:180px;pointer-events:none;overflow:hidden;}
.lf-ocean svg{position:absolute;bottom:0;width:200%;}
#lf-w1{animation:lfWave 9s linear infinite;}
#lf-w2{animation:lfWave 14s linear infinite reverse;opacity:.4;bottom:6px;}
@keyframes lfWave{from{transform:translateX(0)}to{transform:translateX(-50%)}}
/* Stars */
.lf-star{position:absolute;border-radius:50%;background:#fff;pointer-events:none;animation:lfTwink 2s ease-in-out infinite alternate;}
@keyframes lfTwink{from{opacity:.15;transform:scale(1)}to{opacity:.9;transform:scale(1.6)}}
/* Screens */
.lf-screen{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:16px;box-sizing:border-box;overflow:hidden;}
#lf-customizeScreen{padding:0!important;align-items:stretch;justify-content:stretch;}
.lf-screen.hidden{display:none!important;}
/* Login card */
.lf-card{
  background:rgba(4,18,42,0.9);border:1px solid rgba(100,180,255,0.2);
  border-radius:22px;padding:32px 28px 24px;
  width:min(92vw,400px);text-align:center;
  box-shadow:0 20px 60px rgba(0,50,120,0.5);
  backdrop-filter:blur(16px);position:relative;overflow:hidden;
}
#lf-logo{font-size:58px;animation:lfBobble 3.5s ease-in-out infinite;display:block;margin-bottom:4px;}
@keyframes lfBobble{0%,100%{transform:translateY(0) rotate(-4deg)}50%{transform:translateY(-10px) rotate(4deg)}}
.lf-title{font-size:26px;font-weight:900;background:linear-gradient(135deg,#7ecfff,#b0e8ff);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin:0 0 2px;}
.lf-sub{font-size:11px;color:#2a4d6a;letter-spacing:2px;text-transform:uppercase;margin:0 0 22px;}
/* User info */
#lf-userInfo{display:none;align-items:center;gap:10px;background:rgba(126,207,255,.07);border:1px solid rgba(126,207,255,.15);border-radius:12px;padding:10px 14px;margin-bottom:14px;}
#lf-avatar{width:38px;height:38px;border-radius:50%;background:linear-gradient(135deg,#3498db,#7ecfff);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0;overflow:hidden;}
#lf-avatar img{width:100%;height:100%;border-radius:50%;object-fit:cover;}
.lf-utext{text-align:left;flex:1;min-width:0;}
#lf-uname{font-size:14px;font-weight:700;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
#lf-uemail{font-size:10px;color:#3a6a8a;}
#lf-ubadge{font-size:10px;color:#2ecc71;font-weight:700;margin-top:1px;}
/* Inputs */
.lf-label{font-size:10px;color:#2a5070;text-align:left;margin-bottom:4px;display:block;letter-spacing:.5px;text-transform:uppercase;}
.lf-inp{width:100%;box-sizing:border-box;padding:10px 13px;border-radius:10px;border:1px solid rgba(255,255,255,.1);background:rgba(255,255,255,.06);color:#fff;font-size:14px;outline:none;transition:border-color .2s;margin-bottom:11px;}
.lf-inp:focus{border-color:rgba(126,207,255,.45);}
.lf-inp::placeholder{color:rgba(255,255,255,.22);}
/* Buttons */
.lf-btn{width:100%;padding:12px;border:none;border-radius:12px;font-size:14px;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:9px;margin-bottom:9px;transition:opacity .15s,transform .1s;}
.lf-btn:active{transform:scale(.97);opacity:.88;}
.lf-btn:disabled{opacity:.4;cursor:not-allowed;}
#lf-googleBtn{background:#fff;color:#1a1a1a;box-shadow:0 3px 12px rgba(255,255,255,.1);}
#lf-anonBtn{background:rgba(255,255,255,.07);color:#8899aa;border:1px solid rgba(255,255,255,.1);}
#lf-customizeBtn{background:linear-gradient(135deg,#8e44ad,#9b59b6);color:#fff;}
#lf-playBtn{background:linear-gradient(135deg,#27ae60,#2ecc71);color:#fff;box-shadow:0 4px 16px rgba(39,174,96,.4);font-size:15px;}
#lf-signoutBtn{background:rgba(255,255,255,.05);color:#3a6080;border:1px solid rgba(255,255,255,.08);font-size:12px;padding:8px;}
.lf-div{display:flex;align-items:center;gap:9px;margin:2px 0 9px;color:#1e3a52;font-size:11px;}
.lf-div::before,.lf-div::after{content:'';flex:1;height:1px;background:rgba(255,255,255,.06);}
#lf-status{font-size:12px;color:#e74c3c;min-height:16px;margin-top:5px;}
.lf-ok{color:#2ecc71!important;}
#lf-spin{position:absolute;inset:0;background:rgba(2,12,28,.75);display:none;align-items:center;justify-content:center;border-radius:22px;z-index:5;}
.lf-ring{width:32px;height:32px;border-radius:50%;border:3px solid rgba(126,207,255,.2);border-top-color:#7ecfff;animation:lfSpin .8s linear infinite;}
@keyframes lfSpin{to{transform:rotate(360deg)}}

/* ═══════════ CUSTOMIZER — FULL LANDSCAPE ═══════════ */
#lf-customizeScreen{padding:0;}
#lf-custLayout{
  display:flex;width:100%;height:100%;overflow:hidden;
}
/* LEFT: 3D preview */
#lf-previewPanel{
  flex:0 0 42%;max-width:420px;
  background:linear-gradient(160deg,#020f22,#041830);
  border-right:1px solid rgba(100,180,255,.12);
  display:flex;flex-direction:column;
  position:relative;
}
#lf-preview3d{
  flex:1;width:100%;overflow:hidden;
  position:relative;min-height:0;
}
#lf-preview3d canvas{display:block!important;width:100%!important;height:100%!important;object-fit:cover;}
/* Name plate on preview */
#lf-prevNamePlate{
  position:absolute;bottom:0;left:0;right:0;
  background:linear-gradient(transparent,rgba(1,10,24,.95));
  padding:24px 20px 16px;text-align:center;
  pointer-events:none;
}
#lf-prev-name{font-size:16px;font-weight:700;color:#7ecfff;}
#lf-prev-sub{font-size:11px;color:#2a5070;margin-top:2px;}
/* Preview top bar */
#lf-prevTopBar{
  display:flex;align-items:center;justify-content:space-between;
  padding:14px 18px 10px;
  border-bottom:1px solid rgba(100,180,255,.1);
}
#lf-prevTopBar .lf-game-title{font-size:14px;font-weight:700;color:#7ecfff;}
#lf-custBackBtn{
  background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.15);
  color:#aac;border-radius:9px;padding:7px 14px;font-size:13px;
  font-weight:600;cursor:pointer;display:flex;align-items:center;gap:5px;
  transition:background .15s;
}
#lf-custBackBtn:hover{background:rgba(255,255,255,.14);}
#lf-custSaveBtn{
  background:linear-gradient(135deg,#27ae60,#2ecc71);
  border:none;color:#fff;border-radius:9px;padding:7px 18px;font-size:13px;
  font-weight:700;cursor:pointer;display:flex;align-items:center;gap:5px;
  box-shadow:0 3px 12px rgba(39,174,96,.4);transition:opacity .15s;
}
#lf-custSaveBtn:hover{opacity:.88;}

/* RIGHT: options panel */
#lf-optsPanel{
  flex:1;overflow-y:auto;
  padding:0;
  display:flex;flex-direction:column;
  min-width:0;min-height:0;
}
#lf-optsPanel::-webkit-scrollbar{width:4px;}
#lf-optsPanel::-webkit-scrollbar-thumb{background:rgba(126,207,255,.15);border-radius:4px;}
/* Category tabs */
#lf-catTabs{
  display:flex;gap:0;
  border-bottom:1px solid rgba(255,255,255,.07);
  overflow-x:auto;flex-shrink:0;
  background:rgba(2,12,28,.7);
}
#lf-catTabs::-webkit-scrollbar{height:2px;}
.lf-cat-tab{
  flex:1;min-width:60px;padding:12px 6px 10px;
  text-align:center;cursor:pointer;font-size:10px;font-weight:600;
  color:#3a6080;border-bottom:2px solid transparent;
  white-space:nowrap;transition:all .15s;
  display:flex;flex-direction:column;align-items:center;gap:3px;
  background:none;border-top:none;border-left:none;border-right:none;
}
.lf-cat-tab .lf-tab-icon{font-size:18px;}
.lf-cat-tab.active{color:#7ecfff;border-bottom-color:#7ecfff;background:rgba(126,207,255,.06);}
/* Category panels */
.lf-cat-panel{display:none;padding:18px;flex-direction:column;gap:14px;}
.lf-cat-panel.active{display:flex;}
.lf-cat-title{font-size:12px;font-weight:700;color:#7ecfff;margin-bottom:8px;text-transform:uppercase;letter-spacing:1px;}

/* Swatches */
.lf-swatch-row{display:flex;gap:10px;flex-wrap:wrap;}
.lf-swatch{width:36px;height:36px;border-radius:50%;cursor:pointer;border:3px solid transparent;transition:transform .15s,border-color .15s;flex-shrink:0;}
.lf-swatch:hover{transform:scale(1.18);}
.lf-swatch.active{border-color:#7ecfff;transform:scale(1.22);box-shadow:0 0 0 2px rgba(126,207,255,.3);}
/* Chips */
.lf-chips{display:flex;gap:8px;flex-wrap:wrap;}
.lf-chip{padding:8px 14px;border-radius:20px;font-size:12px;font-weight:600;cursor:pointer;background:rgba(255,255,255,.06);color:#7a9ab5;border:1px solid rgba(255,255,255,.1);transition:all .15s;white-space:nowrap;}
.lf-chip:hover{background:rgba(255,255,255,.11);color:#c0d8ee;}
.lf-chip.active{background:rgba(126,207,255,.18);color:#7ecfff;border-color:rgba(126,207,255,.4);}
/* Color dots */
.lf-dot-row{display:flex;gap:9px;flex-wrap:wrap;align-items:center;}
.lf-dot{width:30px;height:30px;border-radius:50%;cursor:pointer;border:3px solid transparent;transition:transform .15s,border-color .15s;flex-shrink:0;}
.lf-dot:hover{transform:scale(1.18);}
.lf-dot.active{border-color:#fff;transform:scale(1.22);box-shadow:0 0 0 2px rgba(255,255,255,.2);}
.lf-cpick{width:30px;height:30px;border:2px solid rgba(255,255,255,.2);border-radius:50%;cursor:pointer;background:none;padding:0;}
/* Color section label */
.lf-sub-label{font-size:10px;color:#2a5070;margin-bottom:6px;margin-top:10px;text-transform:uppercase;letter-spacing:.5px;}

/* Portrait / narrow screen fallback */
@media(max-width:540px){
  #lf-custLayout{flex-direction:column;}
  #lf-previewPanel{flex:0 0 42vh!important;max-width:100%!important;border-right:none!important;border-bottom:1px solid rgba(100,180,255,.12);}
  #lf-preview3d{min-height:0!important;}
  .lf-cat-tab{padding:9px 4px 7px;min-width:46px;font-size:9px;}
  .lf-cat-tab .lf-tab-icon{font-size:16px;}
}
/* Force landscape on small screens via screen orientation lock hint */
@media(orientation:portrait) and (max-width:768px){
  #lf-custLayout{flex-direction:column;}
  #lf-previewPanel{flex:0 0 38vh!important;max-width:100%!important;border-right:none!important;border-bottom:1px solid rgba(100,180,255,.12);}
}
</style>

<div id="lf-stars"></div>
<div class="lf-ocean">
  <svg id="lf-w1" viewBox="0 0 1440 180" preserveAspectRatio="none" style="height:180px">
    <path fill="rgba(14,55,110,0.45)" d="M0,90 C360,150 720,30 1080,90 C1260,120 1350,50 1440,90 L1440,180 L0,180 Z"/>
    <path fill="rgba(8,35,80,0.55)" d="M0,110 C240,70 480,150 720,110 C960,70 1200,140 1440,110 L1440,180 L0,180 Z"/>
  </svg>
  <svg id="lf-w2" viewBox="0 0 1440 180" preserveAspectRatio="none" style="height:145px">
    <path fill="rgba(20,75,150,0.3)" d="M0,70 C480,130 960,10 1440,70 L1440,180 L0,180 Z"/>
  </svg>
</div>

<!-- LOGIN SCREEN -->
<div class="lf-screen" id="lf-loginScreen">
  <div class="lf-card">
    <div id="lf-spin"><div class="lf-ring"></div></div>
    <span id="lf-logo">🎣</span>
    <div class="lf-title">Let's Fishing!</div>
    <div class="lf-sub">Multiplayer Fishing Game</div>
    <div id="lf-userInfo">
      <div id="lf-avatar">👤</div>
      <div class="lf-utext">
        <div id="lf-uname">—</div>
        <div id="lf-uemail">—</div>
        <div id="lf-ubadge">● Masuk</div>
      </div>
    </div>
    <div id="lf-nameSect" style="display:none">
      <label class="lf-label">Nama Karakter</label>
      <input class="lf-inp" id="lf-nameInp" maxlength="14" placeholder="Nama kamu..." autocomplete="off" spellcheck="false">
    </div>
    <div id="lf-roomSect" style="display:none;margin-bottom:11px;">
      <label class="lf-label">Room</label>
      <input class="lf-inp" id="lf-roomInp" maxlength="16" placeholder="world_main" autocomplete="off">
    </div>
    <div id="lf-authBtns">
      <button class="lf-btn" id="lf-googleBtn">
        <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.18 1.48-4.97 2.36-8.16 2.36-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>
        Masuk dengan Google
      </button>
      <div class="lf-div">atau</div>
      <button class="lf-btn" id="lf-anonBtn">👤 Masuk sebagai Tamu</button>
    </div>
    <div id="lf-postBtns" style="display:none">
      <button class="lf-btn" id="lf-customizeBtn">🎨 Kustomisasi Karakter</button>
      <button class="lf-btn" id="lf-playBtn">▶ Mulai Bermain</button>
      <button class="lf-btn" id="lf-signoutBtn">🚪 Ganti Akun</button>
    </div>
    <div id="lf-status"></div>
  </div>
</div>

<!-- CUSTOMIZER SCREEN (LANDSCAPE) -->
<div class="lf-screen hidden" id="lf-customizeScreen">
  <div id="lf-custLayout">

    <!-- LEFT: 3D Preview -->
    <div id="lf-previewPanel">
      <div id="lf-prevTopBar">
        <div class="lf-game-title">🎣 Let's Fishing!</div>
        <div style="display:flex;gap:8px;">
          <button id="lf-custBackBtn">← Back</button>
          <button id="lf-custSaveBtn">✓ Simpan</button>
        </div>
      </div>
      <div id="lf-preview3d"></div>
      <div id="lf-prevNamePlate">
        <div id="lf-prev-name">Player</div>
        <div id="lf-prev-sub">Karakter Kamu</div>
      </div>
    </div>

    <!-- RIGHT: Options -->
    <div id="lf-optsPanel">
      <!-- Category tabs -->
      <div id="lf-catTabs">
        <button class="lf-cat-tab active" data-cat="skin"><span class="lf-tab-icon">🎨</span>Kulit</button>
        <button class="lf-cat-tab" data-cat="hair"><span class="lf-tab-icon">💇</span>Rambut</button>
        <button class="lf-cat-tab" data-cat="face"><span class="lf-tab-icon">😊</span>Wajah</button>
        <button class="lf-cat-tab" data-cat="outfit"><span class="lf-tab-icon">👕</span>Baju</button>
        <button class="lf-cat-tab" data-cat="acc"><span class="lf-tab-icon">🎩</span>Aksesori</button>
      </div>

      <!-- Skin panel -->
      <div class="lf-cat-panel active" id="lf-panel-skin">
        <div>
          <div class="lf-cat-title">Warna Kulit</div>
          <div class="lf-swatch-row" id="lf-skinRow"></div>
        </div>
      </div>

      <!-- Hair panel -->
      <div class="lf-cat-panel" id="lf-panel-hair">
        <div>
          <div class="lf-cat-title">Gaya Rambut</div>
          <div class="lf-chips" id="lf-hairChips"></div>
        </div>
        <div>
          <div class="lf-cat-title" style="margin-top:4px;">Warna Rambut</div>
          <div class="lf-dot-row" id="lf-hairColorRow"></div>
        </div>
      </div>

      <!-- Face panel -->
      <div class="lf-cat-panel" id="lf-panel-face">
        <div>
          <div class="lf-cat-title">Ekspresi Wajah</div>
          <div class="lf-chips" id="lf-faceChips"></div>
        </div>
      </div>

      <!-- Outfit panel -->
      <div class="lf-cat-panel" id="lf-panel-outfit">
        <div>
          <div class="lf-cat-title">Warna Baju</div>
          <div class="lf-dot-row" id="lf-shirtRow"></div>
        </div>
        <div>
          <div class="lf-cat-title" style="margin-top:4px;">Warna Celana</div>
          <div class="lf-dot-row" id="lf-pantsRow"></div>
        </div>
      </div>

      <!-- Accessories panel -->
      <div class="lf-cat-panel" id="lf-panel-acc">
        <div>
          <div class="lf-cat-title">Aksesori</div>
          <div class="lf-chips" id="lf-accChips"></div>
        </div>
      </div>
    </div>

  </div>
</div>
`;
  document.body.appendChild(root);

  // Stars
  const starsEl=root.querySelector("#lf-stars");
  for(let i=0;i<80;i++){
    const s=document.createElement("div");s.className="lf-star";
    const sz=.8+Math.random()*2.5;
    s.style.cssText=`width:${sz}px;height:${sz}px;left:${Math.random()*100}%;top:${Math.random()*78}%;animation-delay:${Math.random()*3}s;animation-duration:${1.5+Math.random()*2.5}s;opacity:${.1+Math.random()*.5}`;
    starsEl.appendChild(s);
  }
  // Stop keystrokes leaking to game
  root.querySelectorAll("input").forEach(inp=>{
    inp.addEventListener("keydown",e=>e.stopPropagation());
    inp.addEventListener("keyup",e=>e.stopPropagation());
  });
  loadChar();
  const savedName=localStorage.getItem("playerName")||"";
  const savedRoom=localStorage.getItem("lastRoom")||"";
  if(root.querySelector("#lf-nameInp")) root.querySelector("#lf-nameInp").value=savedName;
  if(root.querySelector("#lf-roomInp")) root.querySelector("#lf-roomInp").value=savedRoom;
  return root;
}

// ─────────────────────────────────────────────────────────
// CUSTOMIZER LOGIC
// ─────────────────────────────────────────────────────────
function initCustomizer(root){
  let update3D=null;

  // Open 3D preview when screen becomes visible
  function openCustomizer(){
    const container=root.querySelector("#lf-preview3d");
    if(!container) return;
    // Force screen orientation hint (mobile)
    try{ screen.orientation.lock('landscape').catch(()=>{}); }catch(e){}
    // Wait 2 frames for layout to fully compute after screen switch
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(!window.THREE){
        // THREE not loaded yet — show fallback and try again
        container.innerHTML='<div style="display:flex;height:100%;align-items:center;justify-content:center;color:#3a6a9a;font-size:13px;flex-direction:column;gap:8px;"><div style="font-size:36px">⏳</div>Memuat Three.js...</div>';
        // Poll until THREE is available
        const poll=setInterval(()=>{
          if(window.THREE){clearInterval(poll);container.innerHTML="";update3D=init3DPreview(container);}
        },300);
        setTimeout(()=>clearInterval(poll),10000);
        return;
      }
      update3D=init3DPreview(container);
    }));
  }

  // ── Category tabs ──
  root.querySelectorAll(".lf-cat-tab").forEach(tab=>{
    tab.addEventListener("click",()=>{
      root.querySelectorAll(".lf-cat-tab").forEach(t=>t.classList.remove("active"));
      root.querySelectorAll(".lf-cat-panel").forEach(p=>p.classList.remove("active"));
      tab.classList.add("active");
      const panel=root.querySelector("#lf-panel-"+tab.dataset.cat);
      if(panel) panel.classList.add("active");
    });
  });

  function refresh(){if(update3D) update3D();}

  // ── Skin ──
  const skinRow=root.querySelector("#lf-skinRow");
  SKIN_TONES.forEach(tone=>{
    const s=document.createElement("div");
    s.className="lf-swatch"+(charState.skinTone===tone?" active":"");
    s.style.background=tone;
    s.onclick=()=>{
      charState.skinTone=tone;
      skinRow.querySelectorAll(".lf-swatch").forEach(x=>x.classList.remove("active"));
      s.classList.add("active");refresh();
    };
    skinRow.appendChild(s);
  });

  // ── Hair style ──
  const hairChips=root.querySelector("#lf-hairChips");
  HAIR_STYLES.forEach(h=>{
    const c=document.createElement("div");
    c.className="lf-chip"+(charState.hairStyle===h.id?" active":"");
    c.textContent=h.label;
    c.onclick=()=>{
      charState.hairStyle=h.id;
      hairChips.querySelectorAll(".lf-chip").forEach(x=>x.classList.remove("active"));
      c.classList.add("active");refresh();
    };
    hairChips.appendChild(c);
  });

  // ── Hair color ──
  const hairColorRow=root.querySelector("#lf-hairColorRow");
  HAIR_COLORS.forEach(clr=>{
    const d=document.createElement("div");
    d.className="lf-dot"+(charState.hairColor===clr?" active":"");
    d.style.cssText=`background:${clr};${(clr==="#f7e7ce"||clr==="#fff")?"border-color:rgba(200,200,200,.35);":""}`;
    d.onclick=()=>{
      charState.hairColor=clr;
      hairColorRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));
      d.classList.add("active");
      hcPick.value=clr;refresh();
    };
    hairColorRow.appendChild(d);
  });
  const hcPick=document.createElement("input");hcPick.type="color";hcPick.className="lf-cpick";hcPick.title="Warna custom";hcPick.value=charState.hairColor;
  hcPick.oninput=e=>{charState.hairColor=e.target.value;hairColorRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));refresh();};
  hairColorRow.appendChild(hcPick);

  // ── Face ──
  const faceChips=root.querySelector("#lf-faceChips");
  FACE_TYPES.forEach(f=>{
    const c=document.createElement("div");
    c.className="lf-chip"+(charState.faceType===f.id?" active":"");
    c.textContent=f.label;
    c.onclick=()=>{
      charState.faceType=f.id;
      faceChips.querySelectorAll(".lf-chip").forEach(x=>x.classList.remove("active"));
      c.classList.add("active");refresh();
    };
    faceChips.appendChild(c);
  });

  // ── Shirt ──
  const shirtRow=root.querySelector("#lf-shirtRow");
  SHIRT_PRESETS.forEach(clr=>{
    const d=document.createElement("div");
    d.className="lf-dot"+(charState.shirtColor===clr?" active":"");
    d.style.background=clr;
    d.onclick=()=>{
      charState.shirtColor=clr;
      shirtRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));
      d.classList.add("active");sPick.value=clr;refresh();
    };
    shirtRow.appendChild(d);
  });
  const sPick=document.createElement("input");sPick.type="color";sPick.className="lf-cpick";sPick.title="Warna custom";sPick.value=charState.shirtColor;
  sPick.oninput=e=>{charState.shirtColor=e.target.value;shirtRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));refresh();};
  shirtRow.appendChild(sPick);

  // ── Pants ──
  const pantsRow=root.querySelector("#lf-pantsRow");
  PANTS_PRESETS.forEach(clr=>{
    const d=document.createElement("div");
    d.className="lf-dot"+(charState.pantsColor===clr?" active":"");
    d.style.background=clr;
    d.onclick=()=>{
      charState.pantsColor=clr;
      pantsRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));
      d.classList.add("active");pPick.value=clr;refresh();
    };
    pantsRow.appendChild(d);
  });
  const pPick=document.createElement("input");pPick.type="color";pPick.className="lf-cpick";pPick.title="Warna custom";pPick.value=charState.pantsColor;
  pPick.oninput=e=>{charState.pantsColor=e.target.value;pantsRow.querySelectorAll(".lf-dot").forEach(x=>x.classList.remove("active"));refresh();};
  pantsRow.appendChild(pPick);

  // ── Accessories ──
  const accChips=root.querySelector("#lf-accChips");
  ACCESSORIES.forEach(a=>{
    const c=document.createElement("div");
    c.className="lf-chip"+(charState.accessory===a.id?" active":"");
    c.textContent=a.label;
    c.onclick=()=>{
      charState.accessory=a.id;
      accChips.querySelectorAll(".lf-chip").forEach(x=>x.classList.remove("active"));
      c.classList.add("active");refresh();
    };
    accChips.appendChild(c);
  });

  return openCustomizer;
}

// ─────────────────────────────────────────────────────────
// UI STATE HELPERS
// ─────────────────────────────────────────────────────────
function setSpinner(root,on){const sp=root.querySelector("#lf-spin");if(sp)sp.style.display=on?"flex":"none";}
function setStatus(root,msg,ok){const el=root.querySelector("#lf-status");if(!el)return;el.textContent=msg;el.className=ok?"lf-ok":"";}
function showLoggedIn(root,user,dispName){
  const info=root.querySelector("#lf-userInfo"),av=root.querySelector("#lf-avatar");
  const uname=root.querySelector("#lf-uname"),uemail=root.querySelector("#lf-uemail"),ubadge=root.querySelector("#lf-ubadge");
  if(user.isAnonymous){
    av.textContent="👤";uname.textContent=dispName||"Tamu";uemail.textContent="Mode Tamu";
    ubadge.textContent="● Tamu";ubadge.style.color="#f39c12";
    root.querySelector("#lf-nameSect").style.display="block";
    const ni=root.querySelector("#lf-nameInp");if(ni&&!ni.value) ni.value=localStorage.getItem("playerName")||"";
  }else{
    if(user.photoURL){av.innerHTML=`<img src="${user.photoURL}" alt="">`;}
    else{av.textContent=(user.displayName||"U")[0].toUpperCase();}
    uname.textContent=dispName||user.displayName||"Player";
    uemail.textContent=user.email||"";
    ubadge.textContent="● Google";ubadge.style.color="#2ecc71";
    root.querySelector("#lf-nameSect").style.display="none";
  }
  if(info)info.style.display="flex";
  root.querySelector("#lf-roomSect").style.display="block";
  root.querySelector("#lf-authBtns").style.display="none";
  root.querySelector("#lf-postBtns").style.display="block";
  const nm=dispName||(user.isAnonymous?localStorage.getItem("playerName")||"Tamu":user.displayName||"Player");
  const pn=root.querySelector("#lf-prev-name");if(pn)pn.textContent=nm;
  setStatus(root,"");
}
function showLoggedOut(root){
  const info=root.querySelector("#lf-userInfo");if(info)info.style.display="none";
  root.querySelector("#lf-authBtns").style.display="block";
  root.querySelector("#lf-postBtns").style.display="none";
  root.querySelector("#lf-nameSect").style.display="none";
  root.querySelector("#lf-roomSect").style.display="none";
  setStatus(root,"");
}
function showScreen(root,id){
  root.querySelectorAll(".lf-screen").forEach(s=>{s.classList.toggle("hidden",s.id!==id);});
}

// ─────────────────────────────────────────────────────────
// MAIN ENTRY
// ─────────────────────────────────────────────────────────
function startAuthFlow(onReady){
  loadSDKs(()=>{
    const cfg=window.FIREBASE_CONFIG;
    if(!cfg||!cfg.apiKey||cfg.apiKey.includes("ISI")){
      onReady("local_"+Math.random().toString(36).slice(2,8),
              localStorage.getItem("playerName")||"Player",
              localStorage.getItem("playerShirt")||"#2ecc71","world_main");
      return;
    }
    if(!firebase.apps.length) firebase.initializeApp(cfg);
    authInst=firebase.auth();
    window._firebaseAuth=authInst;

    const root=buildUI();
    const openCustomizer=initCustomizer(root);

    // Customize btn
    root.querySelector("#lf-customizeBtn").onclick=()=>{
      showScreen(root,"lf-customizeScreen");
      openCustomizer();
    };
    // Back from customizer
    root.querySelector("#lf-custBackBtn").onclick=()=>{
      if(_previewRaf) cancelAnimationFrame(_previewRaf);
      if(_previewRenderer){try{_previewRenderer.dispose();}catch(e){}_previewRenderer=null;}
      try{if(screen.orientation&&screen.orientation.unlock) screen.orientation.unlock();}catch(e){}
      showScreen(root,"lf-loginScreen");
    };
    // Save customizer
    root.querySelector("#lf-custSaveBtn").onclick=()=>{
      saveChar();applyToGameCharacter();
      if(_previewRaf) cancelAnimationFrame(_previewRaf);
      if(_previewRenderer){try{_previewRenderer.dispose();}catch(e){}_previewRenderer=null;}
      try{if(screen.orientation&&screen.orientation.unlock) screen.orientation.unlock();}catch(e){}
      showScreen(root,"lf-loginScreen");
      setStatus(root,"✅ Karakter disimpan!",true);
    };

    // Play
    function doPlay(){
      if(!curUser) return;
      let playerName,shirtColor,roomId;
      if(curUser.isAnonymous){
        const ni=root.querySelector("#lf-nameInp");
        playerName=(ni?ni.value.trim():"");
        if(!playerName){if(ni)ni.style.borderColor="#e74c3c";setStatus(root,"⚠️ Masukkan nama karakter!");return;}
      }else{
        playerName=localStorage.getItem("playerName")||curUser.displayName||"Player";
      }
      const ri=root.querySelector("#lf-roomInp");
      roomId=((ri?ri.value.trim():"")||"world_main").replace(/\s+/g,"_");
      shirtColor=charState.shirtColor;
      localStorage.setItem("playerName",playerName);
      localStorage.setItem("playerShirt",shirtColor);
      localStorage.setItem("lastRoom",roomId);
      localStorage.setItem("mpId","p_"+curUser.uid.slice(0,8));
      saveChar();
      root.style.transition="opacity .5s";root.style.opacity="0";
      setTimeout(()=>{root.remove();onReady(curUser.uid,playerName,shirtColor,roomId);},500);
    }
    root.querySelector("#lf-playBtn").onclick=doPlay;
    root.querySelector("#lf-nameInp")&&root.querySelector("#lf-nameInp").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();doPlay();}});

    // Google
    root.querySelector("#lf-googleBtn").onclick=async()=>{
      setSpinner(root,true);setStatus(root,"");
      try{
        const prov=new firebase.auth.GoogleAuthProvider();
        prov.setCustomParameters({prompt:"select_account"});
        const res=await authInst.signInWithPopup(prov);
        curUser=res.user;
        if(res.user.displayName) localStorage.setItem("playerName",res.user.displayName.split(" ")[0].slice(0,14));
        showLoggedIn(root,res.user,localStorage.getItem("playerName"));
        setStatus(root,"✅ Login berhasil!",true);
      }catch(err){
        if(err.code==="auth/popup-closed-by-user") setStatus(root,"Login dibatalkan.");
        else if(err.code==="auth/popup-blocked") setStatus(root,"⚠️ Popup diblokir. Coba lagi.");
        else setStatus(root,"⚠️ "+(err.message||"Gagal login"));
      }finally{setSpinner(root,false);}
    };

    // Anonymous
    root.querySelector("#lf-anonBtn").onclick=async()=>{
      setSpinner(root,true);setStatus(root,"");
      try{
        const res=await authInst.signInAnonymously();
        curUser=res.user;showLoggedIn(root,res.user,localStorage.getItem("playerName"));
      }catch(err){setStatus(root,"⚠️ "+(err.message||"Gagal"));}
      finally{setSpinner(root,false);}
    };

    // Sign out
    root.querySelector("#lf-signoutBtn").onclick=async()=>{
      setSpinner(root,true);
      try{await authInst.signOut();curUser=null;showLoggedOut(root);}catch(e){}
      setSpinner(root,false);
    };

    // Restore session
    authInst.onAuthStateChanged(user=>{
      if(user){
        curUser=user;
        const savedName=localStorage.getItem("playerName")||(!user.isAnonymous?(user.displayName||"").split(" ")[0].slice(0,14):"");
        showLoggedIn(root,user,savedName);
      }else{curUser=null;showLoggedOut(root);}
    });
  });
}

// ─────────────────────────────────────────────────────────
// EXPOSE
// ─────────────────────────────────────────────────────────
window.LF_Auth={
  start:    startAuthFlow,
  getUser:  ()=>curUser,
  getChar:  ()=>({...charState}),
  applyChar:applyToGameCharacter,
};
window.dispatchEvent(new Event("lf_auth_ready"));

})();
