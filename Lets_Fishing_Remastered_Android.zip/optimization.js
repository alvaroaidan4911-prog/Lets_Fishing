
// 🎣 LET'S FISHING REMASTER SYSTEM
console.log("Remaster System Loaded");

window.REMASTER = {
  fps: 60,
  lowMode: false,
  smoothFactor: 0.12
};

// ===== MOBILE DETECTION =====
const isMobile = /Android|iPhone|iPad/i.test(navigator.userAgent);

if (isMobile) {
  console.log("📱 Mobile optimization active");
  REMASTER.lowMode = true;
}

// ===== PERFORMANCE HUD =====
let fpsBox = document.createElement("div");
fpsBox.style.position = "fixed";
fpsBox.style.top = "10px";
fpsBox.style.right = "10px";
fpsBox.style.zIndex = "9999";
fpsBox.style.padding = "6px 10px";
fpsBox.style.background = "rgba(0,0,0,0.55)";
fpsBox.style.color = "#fff";
fpsBox.style.borderRadius = "10px";
fpsBox.style.fontFamily = "Arial";
fpsBox.style.fontSize = "12px";
fpsBox.innerHTML = "🎮 FPS: --";
document.body.appendChild(fpsBox);

let frames = 0;
let lastTime = performance.now();

function updateFPS(){
  frames++;
  const now = performance.now();

  if(now - lastTime >= 1000){
    fpsBox.innerHTML = "🎮 FPS: " + frames;
    frames = 0;
    lastTime = now;
  }

  requestAnimationFrame(updateFPS);
}
updateFPS();

// ===== AUTO CLEANUP =====
setInterval(() => {
  const buttons = document.querySelectorAll("#proximityGiftBtn");

  if(buttons.length > 1){
    for(let i=1;i<buttons.length;i++){
      buttons[i].remove();
    }
  }
}, 3000);

// ===== SMOOTH CAMERA =====
if(window.camera){
  let targetX = camera.position.x;
  let targetY = camera.position.y;
  let targetZ = camera.position.z;

  setInterval(() => {
    targetX += (camera.position.x - targetX) * REMASTER.smoothFactor;
    targetY += (camera.position.y - targetY) * REMASTER.smoothFactor;
    targetZ += (camera.position.z - targetZ) * REMASTER.smoothFactor;

    camera.position.set(targetX, targetY, targetZ);
  }, 16);
}

// ===== UI POLISH =====
document.addEventListener("DOMContentLoaded", () => {
  document.body.style.background = "#87CEEB";
  document.body.style.overscrollBehavior = "none";

  const style = document.createElement("style");
  style.innerHTML = `
    *{
      -webkit-tap-highlight-color: transparent;
    }

    button, div{
      transition: all .2s ease;
    }

    button:active{
      transform: scale(.95);
    }

    canvas{
      image-rendering: auto;
    }
  `;
  document.head.appendChild(style);
});

// ===== LOW MODE =====
if(REMASTER.lowMode){
  setInterval(() => {
    if(window.scene){
      scene.traverse((obj) => {
        if(obj.material){
          obj.material.fog = false;
        }
      });
    }
  }, 5000);
}

// ===== SAFE RAF =====
const originalRAF = window.requestAnimationFrame;

window.requestAnimationFrame = function(callback){
  return originalRAF((time)=>{
    callback(time);
  });
};

console.log("✅ Remaster optimization enabled");
